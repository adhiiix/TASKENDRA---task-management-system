
const reloadBtn = document.getElementById('reloadBTN');
if (reloadBtn) {
    reloadBtn.addEventListener('click', function(){
        window.location.href = 'get_started.html';
    });
}
const reloadBtnM = document.getElementById('reloadBTNM');
if (reloadBtnM) {
    reloadBtnM.addEventListener('click', function(){
        window.location.href = 'get_started.html';
    });
}
const loginBtn = document.getElementById('loginBTN');
if (loginBtn) {
    loginBtn.addEventListener('click', function(){
        window.location.href = 'login.html';
    });
}
const homeBtn = document.getElementById('homeBTN');
if (homeBtn) {
    homeBtn.addEventListener('click', function(){
        window.location.href = 'index.html';
    });
}