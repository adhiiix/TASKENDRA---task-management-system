# Taskia-task-management-system
The prequisites needed to make this work is to make sure you launch it with XAMPP to live check and you need database called taskia and a few tables that will be listed below


![image](https://github.com/user-attachments/assets/be2884fc-f36c-4226-9d4c-6f53c96b8109)

home page
![image](https://github.com/user-attachments/assets/50fbfe85-ee97-43ac-8ebb-39a784c007e2)

login page
![image](https://github.com/user-attachments/assets/b76fa9cd-6f7e-4d6b-9053-d1024c2c4da9)

get started page
![image](https://github.com/user-attachments/assets/aaab1cbf-71c6-46c5-9473-6e1729ac5d9b)

panel
![image](https://github.com/user-attachments/assets/d380b523-683e-419e-90e1-503f2be872d1)

tasks page
![image](https://github.com/user-attachments/assets/bf12b0dd-d75f-4172-8d4f-4f925e0d58b2)

add tasks page
![image](https://github.com/user-attachments/assets/94c5ae4c-c995-4406-9f89-12f13a7fb68f)


adding members and members listing will be added soon and is underconstruction
